<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ShipmentAll extends Component
{
    public function render()
    {
        return view('livewire.shipment-all');
    }
}
