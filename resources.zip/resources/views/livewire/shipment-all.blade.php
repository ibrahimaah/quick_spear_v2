<div>
    {{ __($status) }}
</div>
