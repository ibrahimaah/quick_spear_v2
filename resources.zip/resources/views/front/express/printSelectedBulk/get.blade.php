@extends('layouts.app')

@section('content')
{{ $data }}
@endsection
