// (function($) {
//     "use strict";
//      var cal = new tui.Calendar('#calendar-monthly', {
//     defaultView: 'month' // monthly view option
//   });


//        var cal = new tui.Calendar('#calendar', {
//     defaultView: 'week' // weekly view option
//   });


// })(jQuery);

